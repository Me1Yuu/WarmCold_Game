﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WarmCold_Aufgabe
{
    internal class Game
    {
        private int maxNumber;
        private int targetNumber;
        private int attempts;
        private int? previousGuess;
        private int? previousDifference;
        private Random random;

        public Game()
        {
            random = new Random();
        }

        public void Play()
        {
            Initializing();
            bool numberGuessed = false;

            Console.WriteLine ($"Choose a number between 1 and {maxNumber}:\t");

            while (!numberGuessed)
            {
                Console.WriteLine();
                int guess = GetValidInput(1, maxNumber);
                attempts++;
                int difference = Math.Abs(guess - targetNumber);

                if (guess == targetNumber)
                {
                    Console.WriteLine();
                    Console.WriteLine($"Congratulations! You guessed the number: {targetNumber} right!");
                    Thread.Sleep(1500);
                    Console.WriteLine();
                    Console.WriteLine($"You needed {attempts} attempts!");
                    Console.WriteLine();
                    numberGuessed = true;
                }
                else
                {
                    string answer = getAnswer(guess, difference);
                    Console.WriteLine(answer);
                    Console.WriteLine();
                    previousGuess = guess;
                    previousDifference = difference;
                }
            }
        }
        private void Initializing()
        {
            Console.WriteLine("Choose a difficulty:\n1 = Normal (1 - 100)\n2 = Hard (1 - 1000)\n");
            int difficulty = GetValidInput(1, 2);
            maxNumber = difficulty == 2 ? 1000 : 100;
            targetNumber = random.Next(1, maxNumber + 1);
            attempts = 0;
            previousGuess = null;
            previousDifference = null;

        } 

        private int GetValidInput(int min, int max)
        {
            int input;
            bool validInput = false;
            do
            {
                string inputStr = Console.ReadLine();
                if (int.TryParse(inputStr, out input) && input >= min && input <= max)
                {
                    validInput = true;
                }
                else
                {
                    Console.WriteLine($"Please, pick a valid number between {min} an {max}.\n");
                    Console.WriteLine();
                }

            } while (!validInput);
            return input;
        }

        private string getAnswer(int guess, int difference)
        {
            if(previousGuess.HasValue)
            {
                return difference < previousDifference ? "Warm" : "Cold";
            }
            else
            {
                return previousGuess < targetNumber ? "Warm" : "Cold";
            }
        }
    }
}
