﻿using System;
using System.Dynamic;
using System.Security.Cryptography;

namespace WarmCold_Aufgabe
{
    class Program
    {
        static void Main(string[] args)
        {
            bool playAgain = true;

            while (playAgain)
            {
                Game game = new Game();
                game.Play();
                Console.Write("Do you like to play a new game?\t");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Yes\t");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("No");
                Console.ResetColor();
                Console.WriteLine();
                string answer = Console.ReadLine().ToLower();
                playAgain = answer == "yes";
                Console.WriteLine();
            }
        }
    }
}